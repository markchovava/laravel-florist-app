<?php

namespace App\Http\Controllers\Quote;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerQuoteItemController extends Controller
{
    //
}
