window.jsPDF = window.jspdf.jsPDF;
    
$(function () {
    $("#quotation__area").accordion({
    autoHeight: false,
    navigation: true
    });
    $("#generate__pdf").button();
});
  


